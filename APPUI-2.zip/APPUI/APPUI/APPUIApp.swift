//
//  APPUIApp.swift
//  APPUI
//
//  Created by CEDAM08 on 13/04/23.
//

import SwiftUI

@main
struct APPUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
