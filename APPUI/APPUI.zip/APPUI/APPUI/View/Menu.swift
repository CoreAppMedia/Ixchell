//
//  Home.swift
//  APPUI
//
//  Created by CEDAM08 on 14/04/23.
//

import SwiftUI

struct Home: View {
    @Binding var selectedTab: String
    
    init(selectedTab: Binding<String>){
        self._selectedTab = selectedTab
        UITabBar.appearance().isHidden = true
    }
    var body: some View {
     //tab view
        
        TabView(selection: $selectedTab){//vistas
        
                PaginaPricipal()
                    .tag("PaginaPricipal")
                SaintBernard()
                    .tag("SaintBernard")
                Pitbull()
                    .tag("Pitbull")
                Labrador()
                    .tag("Labrador")
                Husky()
                    .tag("Husky")
                Peco()
                    .tag("Peco")
            
                
            
            
            
            

            
        //vistas
            
            
            }
        }
    }

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct PaginaPricipal: View{
    var body: some View{
        NavigationView{
            
            VStack(alignment: .leading, spacing: 20){
                Image("perro")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: getRect().width - 50, height: 400)
                    .cornerRadius(20)
                VStack(alignment: .leading, spacing: 5, content: {
                    Text("DOGGIEPEDIA").foregroundColor(.primary).shadow(color: .gray, radius: 1.08)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .padding()
                        .padding()
                        .padding()
                        .padding()
            
                    
                })
 
                
            }
            .navigationTitle("INICIO")
            
            
            }
        
        }
    
    }
    

    struct SaintBernard: View{
        
        var body: some View{
            
            NavigationView{
                
                VStack(alignment: .leading, spacing: 20){
                    Image("imagen2")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding()
                        Spacer()
                    VStack(alignment: .leading, spacing: 5, content: {
                        Text("Information").foregroundColor(.purple).shadow(color: .gray, radius: 1.08)
                            .font(.title)
                           .padding([.leading, .trailing], 10)
                        Text("HEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("28-30 inches (males)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("26-28 inches (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("WEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("140-180 pounds (male)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("120-140 pounds (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("LIFE EXPECTANCY").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("8-10 years").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Spacer()
                        
                        
                        
                        
                    })
     
                }
                        .navigationTitle("SaintBernard")
            }
        }
    }
    
    struct Pitbull: View{
        var body: some View{
            
            NavigationView{
                
                VStack(alignment: .leading, spacing: 20){
                    Image("pitbull")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding()
                    Spacer()
                    VStack(alignment: .leading, spacing: 5, content: {
                        Text("Information").foregroundColor(.purple).shadow(color: .gray, radius: 1.08)
                            .font(.title)
                            .padding([.leading, .trailing], 10)
                        Text("HEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("19 inches (males)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("18 inches (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("WEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("30-80 Lbs. (male)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("30-80 Lbs. (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("LIFE EXPECTANCY").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("11-13 years").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Spacer()
                        
                        
                    })
                }
                        .navigationTitle("Pitbull")
                
                
            }
        }
    }
    
    struct Labrador: View{
        var body: some View{
            NavigationView{
               
                VStack(alignment: .leading, spacing: 20){
                    Image("labrador")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding()
                    Spacer()
                    VStack(alignment: .leading, spacing: 5, content: {
                        Text("Information").foregroundColor(.purple).shadow(color: .gray, radius: 1.08)
                            .font(.title)
                            .padding([.leading, .trailing], 10)
                        Text("HEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("22.5 - 24.5 inches (males)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("21.5-23 inches (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("WEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("65-80 pounds (male)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("55-70 pounds (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("LIFE EXPECTANCY").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("11-13 years").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Spacer()
                        
                        
                    })
                }
                        .navigationTitle("Labrador")
                
            }
        }
    }
    
    struct Husky: View{
        var body: some View{
            NavigationView{
                
                VStack(alignment: .leading, spacing: 20){
                    Image("husky3")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding()
                    Spacer()
                    VStack(alignment: .leading, spacing: 5, content: {
                        Text("Information").foregroundColor(.purple).shadow(color: .gray, radius: 1.08)
                            .font(.title)
                            .padding([.leading, .trailing], 10)
                        Text("HEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("21-23.5 inches (males)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("20-22 inches (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("WEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("45-60 pounds (male)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("35-50 pounds (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("LIFE EXPECTANCY").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("12-14 years").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Spacer()
                        
                        
                    })
                }
                .navigationTitle("Husky")
                
                
            }
        }
    }
    
    struct Peco: View{
        var body: some View{
            NavigationView{
                
      
                VStack(alignment: .leading, spacing: 20){
                    Image("peco")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding()
                    Spacer()
                    VStack(alignment: .leading, spacing: 5, content: {
                        Text("Information").foregroundColor(.purple).shadow(color: .gray, radius: 1.08)
                            .font(.title)
                            .padding([.leading, .trailing], 10)
                        Text("HEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("22-24 inches (males)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("21-23 inches (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("WEIGHT").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("65-80 pounds (male)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("55-70 pounds (female)").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        Text("LIFE EXPECTANCY").foregroundColor(.purple).bold()
                            .font(.title2)
                            .padding([.leading, .trailing, .top], 10)
                        Text("11-15 years").foregroundColor(.black)
                            .font(.subheadline)
                            .padding([.leading, .trailing, .top], 10)
                        
                        
                        
                        Spacer()
                        
                        
                        
                        
                    })
                }
                        .navigationTitle("Peco")
                
                
            }
        }
    }
    


