//
//  IntentoRecetasApp.swift
//  IntentoRecetas
//
//  Created by CEDAM10 on 01/11/23.
//

import SwiftUI

@main
struct IntentoRecetasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
