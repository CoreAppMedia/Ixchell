//
//  ContentView.swift
//  MenuLateral
//
//  Created by mac20@ioslabacatlan.appleid.com on 15/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
  BaseView()
    }
}

#Preview {
    ContentView()
}
