//
//  MenuLateralApp.swift
//  MenuLateral
//
//  Created by mac20@ioslabacatlan.appleid.com on 15/10/23.
//

import SwiftUI

@main
struct MenuLateralApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
