//
//  RecipeModel.swift
//  PruebaNut
//
//  Created by CEDAM10 on 27/10/23.
//

import Foundation

enum Category: String, CaseIterable, Identifiable{
    var id: String{self.rawValue}
    
    case breakfast = "Breakfast"
    case soup = "Soup"
    case salad = "Salad"
    case appetizer = "Appetizer"
    case main = "Main"
    case side = "Side"
    case dessert = "Dessert"
    case snack = "Snack"
    case drink = "Drink"
    
}

struct Recipe: Identifiable{
    let id = UUID()
    let name: String
    let image: String
    let description: String
    let ingredients: String
    let directions: String
    let category: Category.RawValue
    let datePublished: String
    let url: String
}

extension Recipe {
    static let all: [Recipe] = [
        Recipe(name: "Hamburguesa", image: "hamburguesa-vegana", description: "una hamburguesa proteica vegana hecha a partir de alubias rojas y soja texturizada, además de alguna que otra verdurita. ", ingredients:"400 gr alubias pintas\n1, 1 cebolla, 1/2 pimiento rojo\n1, 4 champiñones, 1/2 bol soja texturizada\n1,Aceite de oliva,Salsa de soja/n1, Pan rallado, Panko (opcional)/n, Pimentón ahumado, Pimienta negra/n1, Curry, Pimentón picanteAjo en grano", directions: "Empezaremos hidratando 1/2 bol de soja texturizada sumergiendolo en agua templada o caliente. Salteando en una sartén con aceite de oliva, 1 cebolla, 1/2 pimiento rojo y  los 4 champiñones. Lo más finamente picado posible para que se integre mejor en las hamburguesas.Cuando esté bien salteado, lo añadimos a un bol y lo mezclamos con las alubias cocidas. Machacamos bien con un tenedor.Sazonamos con un toque de ajo en grano, pimentón picante, pimentón ahumado y mucho curry .Añadimos la soja texturizada y un chorrito de salsa de soja, y mezclamos bien.Ahora, disponemos un plato con pan rallado mezclado con panko.Boleamos un trozo de masa y le damos forma de hamburguesa.", category: "Appetizer", datePublished: "2023-11-03", url: "http:/...com")
    ]
    
}
