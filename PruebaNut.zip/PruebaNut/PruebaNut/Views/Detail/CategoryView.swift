//
//  CategoryView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 29/10/23.
//

import SwiftUI

struct CategoryView: View {
    var category: Category
    
    //Computed property
    var recipe: [Recipe]{
        return Recipe.all.filter{$0.category == category.rawValue}
    }
    
    var body: some View {
        ScrollView{
            RecipeLIst(recipes: Recipe.all.filter{$0.category == category.rawValue})
        }
        .navigationTitle(category.rawValue + "s")
    }
}

#Preview {
    CategoryView(category: Category.dessert)
}
