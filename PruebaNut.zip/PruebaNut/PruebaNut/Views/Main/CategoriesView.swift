//
//  CategoriesView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 26/10/23.
//
// Enumera las recetas por categoria 
import SwiftUI

struct CategoriesView: View {
    var body: some View {
        NavigationView{
            List{
                ForEach(Category.allCases){ category in
                    NavigationLink{
                        ScrollView{
                            RecipeLIst(recipes: Recipe.all.filter{ $0.category == category.rawValue})
                        }
                        .navigationTitle(category .rawValue + "s")
                    }label:{
                        Text(category.rawValue + "s")
                    }
                }
            }
                .navigationTitle("Categorias")
        }
        .navigationViewStyle(.stack)
    }
}

#Preview {
    CategoriesView()
}

