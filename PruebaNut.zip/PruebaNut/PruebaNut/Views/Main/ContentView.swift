//
//  ContentView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 26/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabBar()
    }
}

#Preview {
    ContentView()
}
