//
//  FavoriteView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 26/10/23.
//

import SwiftUI

struct FavoriteView: View {
    var body: some View {
        NavigationView {
            Text("No has agregado nada a tu lista de favoritos")
                .padding()
                .navigationTitle("Receta Nueva")
        }
        .padding()
    }
}

#Preview {
    FavoriteView()
}

