//
//  HomeView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 26/10/23.
//Enumerara las recetas
import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView{
            ScrollView{
                RecipeLIst(recipes: Recipe.all)
            }
            .navigationTitle("My Recipes")
        }
        .navigationViewStyle(.stack)
    }
}
    
    #Preview {
        HomeView()
    }

