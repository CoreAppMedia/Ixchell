//
//  NewRecipeView.swift
//  PruebaNut
//
//  Created by CEDAM10 on 26/10/23.
//
//Agregar nueva receta 
import SwiftUI

struct NewRecipeView: View {
    @State private var showAddRecipe = false
    
    var body: some View {
        NavigationView {
            Button("Add recipe manually"){
                showAddRecipe = true
            }
            .navigationTitle("Receta Nueva")
        }
        .navigationViewStyle(.stack)
        .sheet(isPresented: $showAddRecipe){
            AddRecipeView()
        }
    }
}

#Preview {
    NewRecipeView()
}

