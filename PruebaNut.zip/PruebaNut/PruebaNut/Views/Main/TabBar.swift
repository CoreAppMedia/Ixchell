//
//  TabBar.swift
//  PruebaNut
//
//  Created by CEDAM10 on 29/10/23.
//

import SwiftUI

struct TabBar: View {
    var body: some View {
        TabView{
            HomeView()
                .tabItem{
                    Label("Home", systemImage: "house")
                }
            CategoriesView()
                .tabItem{
                    Label("Categorias", systemImage: "")
                }
            NewRecipeView()
                .tabItem{
                    Label("New", systemImage: "plus")
                }
            FavoriteView()
                .tabItem{
                    Label("Favoritos", systemImage: "heart")
                }
        }
    }
}

#Preview {
    TabBar()
}
